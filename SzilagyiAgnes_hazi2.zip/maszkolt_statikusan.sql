DROP TABLE IF EXISTS UGYFEL_MASKED;

CREATE TABLE UGYFEL_MASKED AS
SELECT
  login,
  
  --Email maszk
  LOWER(SUBSTR(nev, 1, 1)) || '****@maszkolt.com' AS EMAIL,
  
  --Partial maszk
  SUBSTR(nev, 1, 1) || SUBSTR('****************', 1, LENGTH(nev) - 2) || SUBSTR(nev, -1) AS NEV,
  
  szulev,
  nem,
  
  -- Random maszk
  CAST(ABS(RANDOM()) % 9000 + 1000 AS NVARCHAR(4)) || ' ' || SUBSTR(nev, -1) || '*********' AS CIM
FROM ugyfel;

-- Ez az sql fájl szemlélteti csak a feladatot, mivel az online editorban nem tudtam használni a dinamikus maszkolás parancsait. 